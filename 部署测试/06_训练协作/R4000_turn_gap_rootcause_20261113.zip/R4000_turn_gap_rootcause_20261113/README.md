# R4000 转向轮差 ~10× 缺口根因调查包（2026-11-13）

给训练侧的完整证据包：AS2-W R4000（rolling-4000-stage020-research，
model_3999.pt `e46954b6…` / policy.onnx `dd42ada2…`）实机长时间转向轮差只达
软件目标 ~5–11% 的根因调查，含**全部原始现场日志**、可复算脚本与单变量
仿真对照。

**一句话结论：10× ≈ 轮速环结构性力矩上限（kd=2×命令差 → ~1.5 Nm/轮，
实/仿共有 ~3×）× 实机轮地阻力高于 MuJoCo（~3×）；差动唯一来源是开环
0.66·wz 注入（ONNX 差动分量恒零），部署链路其余各级零损失。**

## 读的顺序

1. `report/R4000转向轮差10倍gap根因调查_20261113.md` — 完整报告
   （版本锁定、复算与出入、链路审计、仿真对照、结论分级、修复门槛、补采清单）
2. `report/chain_sync_turnR.png` — 右转窗八联同步图（命令→ONNX→软件目标→发布→实测→tau→后腿→通信龄）
3. `analysis/stage_table.csv` — 全部分阶段链路统计
4. `analysis/turngain_and_closedloop_summary.txt` — 开环增益×1/2/5/10、
   有界偏航反馈 Kp=3/8/20、实机波形回放 E1–E4 三系列汇总表
5. `scripts/` — 三个可复算脚本（见"复现"节）
6. `sim/` — 上述系列的原始输出（mujoco-rolling-diagnostic.json / session-replay-trace.json）
7. `replay/` — **6101 帧实机观测回放夹具** + C++ 回放输出 + `compare_r4000_replay.py`
   （你们 compare_actor_replay.py 的 R4000 前缀版），可对任意 checkpoint 回放
8. `data/` — **全部原始现场日志**（三次运动会话各七文件全量 + 两次 dry-run 档案）

## 原始数据（data/）

| 会话 | 内容 | 说明 |
|---|---|---|
| `20261113-114335_r4000/` | debug_policy.csv（6117 帧全量 65 维观测+raw/包装/前后目标）、debug_lowcmd.csv（74237 行 500 Hz 最终发布）、low_capture_fast.log（2 ms LowState 全程）、low_protection.log、policy_diag.log、publisher.log、session.log | **主分析对象**：120 s，±0.4 m/s + 双向转向；右转窗 [1978:2560]（tick 1694429–1706070）、左转窗 [2921:3557]（tick 1713290–1726009） |
| `20261113-112630_r4000/`、`20261113-112750_r4000/` | 同上七文件 | ±0.2 m/s 对照会话（各 30 s） |
| `20261113-111012/112058_r4000-dry-run/` | 预检日志 | 只读 dry-run，无策略运动 |

字段与坐标约定：debug_policy/observation 为 65 维（vx−0.4 / gyro / gravity /
0.4 / 12 腿角−参考 / 4 轮角回绕 / 16 dq / 上一帧包装动作 / sin-cos / 零速轮角记忆 / 零命令标记）；
轮合同序 FL,FR,RL,RR ↔ LowState 槽 13,12,15,14（本调查从发布流自推导验证）；
debug_lowcmd 每帧显式列出槽位；capture 中 tau 为 LowState 回传的驱动器力矩估计。
已知缺陷：本会话 policy_diag.log 缺 WALK 行（发布端诊断门一行 bug，已在部署侧修复；
全部分析使用 debug_policy.csv 超集，无影响）。

## 复现

```bash
# 1) 槽位自推导 + 链路重算（对 data/20261113-114335_r4000）
python3 scripts/recompute.py data/20261113-114335_r4000

# 2) 分阶段链路表 + 塌缩/下沉时序 + 同步图
python3 scripts/analyze_windows.py data/20261113-114335_r4000 out_dir

# 3) 实机命令波形回放的 MuJoCo 单变量对照（E1–E4）
#    依赖：训练快照代码 + omni 运行时 + 平面资产；PYTHONPATH 见脚本头部
R4000_REPLAY_SESSION=data/20261113-114335_r4000 \
R4000_REPLAY_T0_TICK=1694429 R4000_REPLAY_SECONDS=11.6 \
R4000_WHEEL_SOURCE=wrapper R4000_LEG_SOURCE=policy \
R4000_FRICTION_SCALE=1 R4000_WHEEL_KD_SCALE=1 R4000_TURN_GAIN=1 \
python3 scripts/eval_session_replay.py out_e1 <model_3999.pt> <assets>
#    开环增益/闭环反馈系列用 scripts/eval_r4000_gain_yawfb.py +
#    scripts/r4000_gain_patched_as2w_rolling_fixed_exit.py（R4000_TURN_GAIN/R4000_YAW_KP 环境变量）

# 4) 任意 checkpoint 在实机观测上的回放
cd replay && python3 compare_r4000_replay.py session_replay_bundle.zip <baseline.pt> <candidate.pt> report.json --onnx <policy.onnx>
```

## 期望复现的关键数字

- 实机长转（右转 11.6 s）：软件目标差 −1.146/−1.426/−1.529（首 1 s/3–5 s/末 5 s），
  实测 −0.361/−0.068/−0.167，偏航 21%/5%/15%，`tau_est≈2×速度误差`（斜率 1.89–2.01），
  tau 峰 ≤3.4 Nm/轮（守卫 8/12 Nm 远未触及）。
- MuJoCo 同窗（E1）：实测差 −0.270/−0.414/−0.323（不塌缩）、偏航 38%。
- kd×4/×10（E4a/b）：差动 73%/91%、偏航 86%/106%。
- 开环注入 ×2/×5/×10：偏航 168%/638%/1507% 超调失稳；闭环 Kp=3：89% 跟踪、0 触地。

## 与训练侧的衔接

`skills/as2w/rolling/r4000-turn-20k.md`（commit cda4eea）方向与本证据一致；
报告 §六建议训练课程补两项：持续转驻留 ≥10 s（现 1.1–3.4 s 在塌缩盲区），
轮地摩擦随机化上界扩到 MuJoCo 的 ~3×（否则仿真侧永远到不了实机 5–11% 平衡点）。
本包所有现场片段未用于调参；回放夹具帧索引与会话帧一致可直接引用。

校验：`MANIFEST.sha256`。
