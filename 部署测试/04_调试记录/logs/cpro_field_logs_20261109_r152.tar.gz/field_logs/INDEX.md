
## 2026-11-09T09:17:34+08:00 — preflight

- Exit code: `0`
- Raw log: `field_logs/20261109-091730_preflight_37776.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:17:50+08:00 — build

- Exit code: `0`
- Raw log: `field_logs/20261109-091746_build_37862.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:18:03+08:00 — policy-list

- Exit code: `0`
- Raw log: `field_logs/20261109-091802_policy-list_38049.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:18:03+08:00 — policy-verify

- Exit code: `0`
- Raw log: `field_logs/20261109-091803_policy-verify_38068.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:18:03+08:00 — policy-bench

- Exit code: `0`
- Raw log: `field_logs/20261109-091803_policy-bench_38092.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:18:04+08:00 — policy-bench

- Exit code: `0`
- Raw log: `field_logs/20261109-091804_policy-bench_38042.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:20:38+08:00 — sdk-build

- Exit code: `0`
- Raw log: `field_logs/20261109-092025_sdk-build_38864.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:21:41+08:00 — sport-state

- Exit code: `134`
- Raw log: `field_logs/20261109-092141_sport-state_39439.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:24:09+08:00 — sport-state

- Exit code: `0`
- Raw log: `field_logs/20261109-092358_sport-state_39915.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:24:23+08:00 — motion-mode

- Exit code: `0`
- Raw log: `field_logs/20261109-092423_motion-mode_40039.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:24:40+08:00 — low-state

- Exit code: `134`
- Raw log: `field_logs/20261109-092435_low-state_40193.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:29:11+08:00 — low-state

- Exit code: `0`
- Raw log: `field_logs/20261109-092908_low-state_41205.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:29:41+08:00 — remote-state

- Exit code: `1`
- Raw log: `field_logs/20261109-092931_remote-state_41306.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:32:08+08:00 — low-remote

- Exit code: `0`
- Raw log: `field_logs/20261109-093203_low-remote_41965.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:32:28+08:00 — sport-state

- Exit code: `0`
- Raw log: `field_logs/20261109-093226_sport-state_42063.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:36:57+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-093656_sport-command_43167.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:38:11+08:00 — sdk-build

- Exit code: `0`
- Raw log: `field_logs/20261109-093810_sdk-build_43442.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:41:52+08:00 — sdk-build

- Exit code: `0`
- Raw log: `field_logs/20261109-094150_sdk-build_44383.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:43:08+08:00 — sdk-build

- Exit code: `0`
- Raw log: `field_logs/20261109-094256_sdk-build_44737.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:43:23+08:00 — service-list

- Exit code: `0`
- Raw log: `field_logs/20261109-094323_service-list_44943.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:43:30+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-094330_sport-command_44994.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:43:39+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-094339_sport-command_45049.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:43:46+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-094346_sport-command_45110.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:45:40+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-094540_sport-command_45671.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:47:07+08:00 — sdk-build

- Exit code: `0`
- Raw log: `field_logs/20261109-094656_sdk-build_45932.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:47:15+08:00 — package-version

- Exit code: `1`
- Raw log: `field_logs/20261109-094715_package-version_46131.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:49:32+08:00 — low-remote

- Exit code: `0`
- Raw log: `field_logs/20261109-094917_low-remote_46590.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:50:33+08:00 — low-remote

- Exit code: `0`
- Raw log: `field_logs/20261109-095028_low-remote_46958.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:53:29+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-095329_sport-command_47608.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:53:57+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-095357_sport-command_47729.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:54:27+08:00 — sdk-build

- Exit code: `0`
- Raw log: `field_logs/20261109-095426_sdk-build_47876.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:54:34+08:00 — package-version

- Exit code: `1`
- Raw log: `field_logs/20261109-095434_package-version_48014.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:59:37+08:00 — sdk-build

- Exit code: `0`
- Raw log: `field_logs/20261109-095926_sdk-build_49137.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T09:59:48+08:00 — low-capture

- Exit code: `0`
- Raw log: `field_logs/20261109-095945_low-capture_49394.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T10:01:24+08:00 — low-capture

- Exit code: `0`
- Raw log: `field_logs/20261109-100054_low-capture_49683.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T10:28:02+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-102802_sport-command_56059.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T10:45:55+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-104554_sport-command_60115.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T11:27:36+08:00 — sdk-build

- Exit code: `0`
- Raw log: `field_logs/20261109-112724_sdk-build_5073.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T11:27:49+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-112748_sport-command_5277.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T11:28:05+08:00 — policy-shadow

- Exit code: `0`
- Raw log: `field_logs/20261109-112756_policy-shadow_5340.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T11:37:45+08:00 — sdk-build

- Exit code: `0`
- Raw log: `field_logs/20261109-113730_sdk-build_7696.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T11:37:51+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-113751_sport-command_7955.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T11:45:09+08:00 — low-capture

- Exit code: `0`
- Raw log: `field_logs/20261109-114009_low-capture_8487.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T11:45:12+08:00 — sport-state

- Exit code: `0`
- Raw log: `field_logs/20261109-114011_sport-state_8518.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T11:45:13+08:00 — policy-shadow

- Exit code: `0`
- Raw log: `field_logs/20261109-114013_policy-shadow_8551.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T11:46:08+08:00 — low-capture

- Exit code: `0`
- Raw log: `field_logs/20261109-114107_low-capture_8799.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T11:46:10+08:00 — policy-shadow

- Exit code: `0`
- Raw log: `field_logs/20261109-114109_policy-shadow_8861.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T11:46:10+08:00 — sport-state

- Exit code: `0`
- Raw log: `field_logs/20261109-114109_sport-state_8830.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T13:58:23+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-135823_sport-command_39488.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:07:19+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-140719_sport-command_41482.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:07:35+08:00 — low-capture

- Exit code: `0`
- Raw log: `field_logs/20261109-140729_low-capture_41548.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:17:04+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-141703_sport-command_43802.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:22:12+08:00 — low-capture

- Exit code: `0`
- Raw log: `field_logs/20261109-141712_low-capture_43852.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:22:34+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-142233_sport-command_45282.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:27:42+08:00 — low-capture

- Exit code: `134`
- Raw log: `field_logs/20261109-142242_low-capture_45330.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:30:11+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-143011_sport-command_46997.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:36:01+08:00 — low-capture

- Exit code: `0`
- Raw log: `field_logs/20261109-143101_low-capture_47358.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:37:27+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-143727_sport-command_48736.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:42:37+08:00 — low-capture

- Exit code: `134`
- Raw log: `field_logs/20261109-143736_low-capture_48792.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:43:52+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-144352_sport-command_50178.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:49:14+08:00 — low-capture

- Exit code: `0`
- Raw log: `field_logs/20261109-144414_low-capture_50286.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:50:28+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-145028_sport-command_51733.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:55:37+08:00 — low-capture

- Exit code: `0`
- Raw log: `field_logs/20261109-145036_low-capture_51793.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T14:56:12+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-145612_sport-command_53112.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T15:41:55+08:00 — r152-build

- Exit code: `0`
- Raw log: `field_logs/20261109-154142_r152-build_63294.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T15:42:07+08:00 — r152-replay

- Exit code: `0`
- Raw log: `field_logs/20261109-154207_r152-replay_63673.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T15:42:21+08:00 — sport-command

- Exit code: `0`
- Raw log: `field_logs/20261109-154221_sport-command_63754.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T15:42:47+08:00 — r152-shadow

- Exit code: `1`
- Raw log: `field_logs/20261109-154236_r152-shadow_63837.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T15:43:24+08:00 — low-state

- Exit code: `0`
- Raw log: `field_logs/20261109-154320_low-state_64082.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T15:46:06+08:00 — r152-build

- Exit code: `0`
- Raw log: `field_logs/20261109-154559_r152-build_64697.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**

## 2026-11-09T15:46:27+08:00 — r152-shadow

- Exit code: `0`
- Raw log: `field_logs/20261109-154616_r152-shadow_64944.log`
- Observed result: **to be reviewed**
- Decision and next gate: **to be filled after review**
